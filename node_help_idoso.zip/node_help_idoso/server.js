let express = require('express')();
let conexao = require("./config/conexao")();
let parser = require("body-parser");
let cor = require("cors");

express.use(parser.json());
express.use(cor());

express.post('/cadastro', (req, res) => {
    let cadastro = req.body;
    
    let values = [""];
    values.length = 0;
    values.push(req.body.nome);
    //values.push(req.body.cpf);
    values.push(req.body.email);
    values.push(req.body.nascimento);
    values.push(req.body.sexo);
    values.push(req.body.senha);

conexao.query("insert into cliente(nome,email,nascimento,sexo,senha) values (?)", [values], (err, dados) => {
    console.log(values);
    res.send(true);
});


})
express.post('/login', (req, res) =>{
    let login = req.body.login;
    let senha = req.body.senha;
    
    
    conexao.query(`select * from cliente where email = "${login}" and senha = "${senha}";`,(err, dados) =>{
        res.send(dados);
        console.log(dados);
        console.log(login,senha);
    });
})




express.listen(3000,() => console.log("servidor rodando"));

