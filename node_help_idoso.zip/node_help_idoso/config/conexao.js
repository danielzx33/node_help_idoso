module.exports = () => {
    let mysql = require('mysql');
    let conexao = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: 'guimazx33',
        database: "cliente"
    });

    return conexao;
}